package com.json;

import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.ws.rs.*;

import org.apache.tomcat.jni.User;

import com.google.gson.Gson;

@Path("/json")
public class json extends HttpServlet{
	
	@GET
	@Produces("application/json")
	protected void doGet(HttpServlet req, HttpServletResponse resp) throws ServletException, IOException{
			
		user user = new user(12,"salad");
		Gson gson = new Gson();
		
		System.out.println(gson.toJson(user));

	}
}
